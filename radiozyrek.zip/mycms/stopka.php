
<!-- Stopka strony -->
<footer class="site-footer" id="footer">
  <div class="container">
    <p>

      &copy; Jan Żyrek 2016.
  </p>
  </div></footer>

</body>
</html>
