<?php
require_once("naglowek.php");
 ?>
 <?php
 require_once("stopka.php");
  ?>
