<?php
//użycie funkcji na początku
ob_start();
require_once("naglowek.php");
 ?>
 <?php
 require_once("connect.php"); // 1
 $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
 echo'<br/><br/><h1>Formularz dodawania wydarzenia do historii: </h1><br/><br/>
 <form class="add-event" method="post">
   Podaj rok: <input type="number" name="rok">
   <br>Podaj miesiac: <input type="number" name="miesiac">
   <br>Podaj krotki opis: <textarea name="krotki-opis" rows="8" cols="40"></textarea>
   <br><input type="submit" value="Dodaj" action="">
 </form>';
 if(($_SERVER['REQUEST_METHOD'] == 'POST') && (isset($_POST['krotki-opis'])))
 {
 $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
 $sql2 = "INSERT INTO historia values('','".$_POST['rok']."','".$_POST['miesiac']."','".$_POST['krotki-opis']."')";
 $query2 = $polaczenie->query($sql2);
 header("Location: index.php");
 }
 require_once("stopka.php");
 ob_end_flush();
  ?>
