<?php
//użycie funkcji na początku
ob_start();
require_once("naglowek.php");
 ?>
 <?php
 require_once("connect.php"); // 1
 $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
 $sql6 = "SELECT * from historia order by rok"; // 2
 $query6 = @$polaczenie->query($sql6);
 echo '<div class="container">
   <br><br>
   <h2>Usun wydarzenie z historii</h2>
   <form class="add-event" action="" method="post">
     <select name="id" >';
     while($rekord6 = mysqli_fetch_array($query6))
     {
     echo '<option value="'.$rekord6[0].'">Data: '.$rekord6[1].' . '.$rekord6[2].'<br>';
     }
     echo '</select><input type="submit" value="Usuń">
   </form>
 </div>';
 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
   $sql = "DELETE FROM historia WHERE id = '".$_POST['id']."' LIMIT 1"; // 2
   $query = @$polaczenie->query($sql);
   header("Location: index.php");
 }
 require_once("stopka.php");
 ob_end_flush();
  ?>
