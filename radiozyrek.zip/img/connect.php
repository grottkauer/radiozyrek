<?php

	$host = "mysql.cba.pl";
	$db_user = "radiozyrek";
	$db_password = "2015Moja_LP";
	$db_name = "radiozyrek";

?>
