<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Pierwsza strona</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/fontello.css" type="text/css" />
        <link rel="stylesheet" href="SlickNav/dist/slicknav.css" />
        <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
    </head>
    <body>
        <!-- Naglowek strony -->
        <header class="top" id="pasek">
          <div class="container">
              <div class="logo">
                  <a href="index.php">GRODKOWIACY</a>
              </div>
                  <ul class="main-menu" id="menu">
                       <li ><a href="index.php">Strona główna</a></li>
                       <li ><a href="aktual.php">Aktualnosci</a></li>
                       <li ><a href="#">Zespol</a>
                            <ul class="o-zespole">
                                 <li ><a href="kalendarz.php">Kalendarz wystepow</a></li>
                                 <li ><a href="historia.php">Historia zespolu</a></li>
                                 <li ><a href="galeria.php">Galerie zdjec</a></li>
                                 <li ><a href="prowadzace.php">Prowadzace</a></li>
                            </ul>
                       </li>
                       <li ><a href="#">Zajecia</a>
                            <ul>
                                 <li ><a href="plan.php">Plan zajec</a></li>
                                 <li ><a href="zapisy.php">Zapisy</a></li>
                            </ul>
                        </li>
                        <li ><a href="kontakt.php">Kontakt</a></li>
                        <li ><a href="logowanie.php">Logowanie</a></li>
                  </ul>
              </div>
        </header>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
        <script src="SlickNav/dist/jquery.slicknav.js"></script>
        <script type="text/javascript">
        $(document).ready(function(){
          $('#menu').slicknav();
        });
        </script>
