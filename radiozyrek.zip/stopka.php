
<!-- Stopka strony -->
<footer class="site-footer" id="footer">
  <div class="container">
<?php require_once("licznik.php"); ?>
    <p>

      &copy; Jan Żyrek 2016. Ta strona korzysta z plikow cookies.
  </p>
  </div></footer>

</body>
</html>
