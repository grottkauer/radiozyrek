<?php include('naglowek.php'); ?>
<h1>WIEŚCI DOPIERO W LISTOPADZIE</h1>
<?php

 ?>
<?php include('stopka.php'); ?>
