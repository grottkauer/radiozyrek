
<?php include('naglowek.php'); ?>

<!-- BANNER -->
		<div class="banner">
				<h1>ZOBACZ NAJNOWSZE NOTOWANIE!</h1>
		</div>
<!-- NOTOWANIE -->
				<div class="notowanie">

						<?php
						require_once("connect.php"); // 1
						$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
						$sql1 = "SELECT * from notowania ORDER BY numer_not DESC LIMIT 1 ";
			      $query = $polaczenie->query($sql1);

						$rekord = mysqli_fetch_array($query);
						$numer_notowania = $rekord[2];
						$data = $rekord[1];

						$sql2 = "SELECT * from notowania WHERE numer_not = $numer_notowania ORDER BY miejsce ASC";
			      $query = $polaczenie->query($sql2);

						$ile = 1;
						echo '<a href="notowanie.php?id='.$numer_notowania.'"><h2>NUMER NOTOWANIA: '.$numer_notowania.'   DATA: '.$data.'</h2></a><br>';
						while($rekord = mysqli_fetch_array($query))
			      {
							$sql3 = "SELECT * from utwory WHERE id = $rekord[4] ";
				      $query2 = $polaczenie->query($sql3);
							$utwor = mysqli_fetch_array($query2);

							// Obliczanie liczby tygodni danego utworu
							$sql4 = "SELECT * from notowania WHERE id_utworu = $rekord[4] ";
							$query3 = $polaczenie->query($sql4);
							$liczTyg = mysqli_num_rows($query3);

							if ($liczTyg==1) {
								$ostatni = "N";
								$zmiana = "N";
							}
							else {
								$sql5 = "SELECT * from notowania WHERE numer_not = $numer_notowania-1 AND id_utworu = $rekord[4]";
					      $query5 = $polaczenie->query($sql5);
								$utworek = mysqli_fetch_array($query5);
								$ostatni = $utworek[5];
								if (($zmiana=$ostatni-$rekord[5]) > 0) {
									$zmiana = "+$zmiana";
								}
							}

							if ($ile == 31) {
								echo "<h2>POCZEKALNIA</h2><BR>";
							}

							// Dodawanie fotek obok utworów
							$sql6 = "SELECT * from obrazki WHERE id_utworu = $rekord[4]";
							$query6 = $polaczenie->query($sql6);
							if($utwory = mysqli_fetch_array($query6))
							{
								echo '<div class="notowanie-top"><div class="col-one-third"><a href="utwory.php?id='.$rekord[4].'"><img src="'.$utwory[3].'" alt="Fotka probna" /></a></div><div class="col-two-third"><h3><a href="utwory.php?id='.$rekord[4].'">'.$ile.'. | '.$liczTyg.' tyg | '.$ostatni.' | '.$zmiana.' | '.$utwor[2].' - '.$utwor[3].'</a></h3></div></div><br>';
							}
							else {
								echo '<div class="notowanie-top"><div class="col-one-third"><a href="utwory.php?id='.$rekord[4].'"><img src="img/logo.jpg" alt="Fotka probna" /></a></div><div class="col-two-third"><h3><a href="utwory.php?id='.$rekord[4].'">'.$ile.'. | '.$liczTyg.' tyg | '.$ostatni.' | '.$zmiana.' | '.$utwor[2].' - '.$utwor[3].'</a></h3></div></div><br>';
							}
										//printf("%d. %s - %s\n",$ile, $utwor[2], $utwor[3]);
								$ile++;

						}
						 ?>
				</div>

				<div class="container">
					<div class="col-half">
						<h2>Szukaj</h2>
						<form class="" action="szukaj.php" method="post">
							<select name="rodzaj">
								<option value="Notowanie">Notowanie</option>
								<option value="Wykonawca">Wykonawca</option>
								<option value="Utwor">Utwór</option>
							</select>
							<input type="text" name="wartosc_wysz">
							<input value="Szukaj" type="submit" />
						</form>
					</div>
					<div class="col-half">

					</div>
				</div>
				<div class="clear">

				</div>

<?php include('stopka.php'); ?>
