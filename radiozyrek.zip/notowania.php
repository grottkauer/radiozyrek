<?php include('naglowek.php');
include("connect.php");
$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
 ?>
<h1>NOTOWANIA NA MOJEJ LP</h1>
<?php
  $lata = array();
  $sql2 = "SELECT * from notowania order by data asc limit 1"; // 2
  $query2 = $polaczenie->query($sql2);
  $i=0;
  $rekord2 = mysqli_fetch_array($query2);
  $rok_najstarszy = date("Y",strtotime($rekord2[1]));
  $first_not = $rekord2[2];
  //echo $rok_najstarszy;
 ?>


 <div class="container">
   <?php
      $rok_obecny = date("Y");
      $tekst = '<div class="col-half notowanka">';
      while ($rok_najstarszy<=$rok_obecny) {
        $tekst.= ' <a href="#"><div id="flip'.$rok_najstarszy.'">'.$rok_najstarszy.'</div></a>
         <a href="#"><div id="panel'.$rok_najstarszy.'">';

         //$datka = $rok_najstarszy."-01-01";
         //echo $datka;
         //$pomocnicza = "%Y-%m-%d";
         $sql3 = "SELECT * from notowania order by data desc"; // 2
         $query3 = $polaczenie->query($sql3);
         $ostatni_nr = -1;
         while($rekord3 = mysqli_fetch_array($query3))
         {
          $rok_sqlowy = date("Y",strtotime($rekord3[1]));
           if ($rok_sqlowy == $rok_najstarszy) {
             $nr = $rekord3[2];
             if ($nr!=$ostatni_nr) {
               $ostatni_nr = $nr;
               //echo $ostatni_nr;
               $tekst.= '<a href="#"><div id="panel'.$rok_najstarszy.'_'.$ostatni_nr.'">'.$ostatni_nr.'</div></a><br>';
               $tekst.= '<div id="notowanie'.$ostatni_nr.'">';
               // Wyświetlenie całego notowania
               $sql4 = "SELECT * from notowania where numer_not=$ostatni_nr order by miejsce asc"; // 2
               $query4 = $polaczenie->query($sql4);
               $tekst.= '<div class="terminarz">
                 <table class="table-calendar">
                   <caption>NOTOWANIE NR: '.$ostatni_nr.'</caption>';
              $tekst.='<tr class="col-calendar">
                     <th colspan="6">
                       2017
                     </th>
                   </tr>
                   <tr class="col-calendar">
                     <td class="lp">
                       Lp.
                     </td>
                     <td class="date">
                       Tytuł
                     </td>
                     <td class="event-name">
                       Autor
                     </td>
                     <td class="lp">
                       Ostatnio
                     </td>
                     <td class="lp">
                       Zmiana
                     </td>
                     <td class="lp">
                       L. tyg.
                     </td>
                   </tr>';
               while($rekord4 = mysqli_fetch_array($query4))
               {
                 $lp = $rekord4[5];
                 $id_utworu = $rekord4[4];
                 // Obliczanie liczby tygodni każdego utworku
                 $sql7 = "SELECT * FROM notowania WHERE id_utworu=$id_utworu";
                 $query7 = $polaczenie->query($sql7);
                 $lTyg = mysqli_num_rows($query7);
                 // Obliczanie zmiany miejsca i jego ostatniej pozycji
                 $nr_not = $rekord4[2];
                 $miejsce = $rekord4[5];
                 if ($lTyg==1) {
                   $zmiana="N";
                   $ostatni="N";
                 }
                 else {
                   $sql5 = "SELECT * from notowania WHERE numer_not = $nr_not-1 AND id_utworu = $id_utworu";
                   $query5 = $polaczenie->query($sql5);
                   $utworek = mysqli_fetch_array($query5);
                   $ostatni = $utworek[5];
                   if (($zmiana=$ostatni-$miejsce) > 0) {
                     $zmiana = "+$zmiana";
                   }
                 }


                 // Wczytanie nazwy utworu z bazy
                 $sql2 = "SELECT * from utwory where id=$id_utworu"; // 2
                 $query2 = @$polaczenie->query($sql2);
                 $utwory2 = mysqli_fetch_array($query2);

                 $nazwa_utworu = $utwory2[2];
                 $wykonawca = $utwory2[3];
                 $tekst.= '<tr class="col-calendar">
                   <td class="lp">'.$lp.'</td>
                   <td class="date"><a href="utwory.php?id='.$utwory2[0].'">'.$nazwa_utworu.'</a></td>
                   <td class="event-name">'.$wykonawca.'</td>
                   <td class="lp">'.$ostatni.'</td>
                   <td class="lp">'.$zmiana.'</td>
                   <td class="lp">'.$lTyg.'</td>
                 </tr>';
               }

               $tekst .= '</table></div></div>';
             }
           }
         }

         $tekst.= '</div></a>';

         $rok_najstarszy++;
      }
      $tekst.= "</div>";
      echo $tekst;
    ?>
 </div>
 <div class="clear">

 </div>
 <script type='text/javascript'>
 $(document).ready(function(){
    $("#flip2015").click(function(){
        $("#panel2015").slideToggle("slow");
    });
    $("#flip2016").click(function(){
        $("#panel2016").slideToggle("slow");

    });
    $("#panel2016_52").click(function(){
        $("#notowanie52").slideToggle("slow");
    });
    //$("#panel2016").click(function(){
    //      $("#notowanie2016").slideToggle("slow");
      //};
    $("#flip2017").click(function(){
        $("#panel2017").slideToggle("slow");
    });
    $("#panel2017_99").click(function(){
        $("#notowanie99").slideToggle("slow");
    });
    $("#panel2017_101").click(function(){
        $("#notowanie101").slideToggle("slow");
    });
    $("#panel2017_102").click(function(){
        $("#notowanie102").slideToggle("slow");
    });
    $("#panel2017_103").click(function(){
        $("#notowanie103").slideToggle("slow");
    });
    $("#panel2017_104").click(function(){
        $("#notowanie104").slideToggle("slow");
    });
    $("#panel2017_105").click(function(){
        $("#notowanie105").slideToggle("slow");
    });
    $("#panel2017_106").click(function(){
        $("#notowanie106").slideToggle("slow");
    });
    $("#panel2017_107").click(function(){
        $("#notowanie107").slideToggle("slow");
    });
    $("#panel2017_108").click(function(){
        $("#notowanie108").slideToggle("slow");
    });
    $("#panel2017_109").click(function(){
        $("#notowanie109").slideToggle("slow");
    });
    $("#flip2018").click(function(){
        $("#panel2018").slideToggle("slow");
    });
    $("#flip2019").click(function(){
        $("#panel2019").slideToggle("slow");
    });
    $("#flip2020").click(function(){
        $("#panel2020").slideToggle("slow");
    });
    $("#flip2021").click(function(){
        $("#panel2021").slideToggle("slow");
    });
    $("#flip2022").click(function(){
        $("#panel2022").slideToggle("slow");
    });
    $("#flip2023").click(function(){
        $("#panel2023").slideToggle("slow");
    });
    $("#flip2024").click(function(){
        $("#panel2024").slideToggle("slow");
    });
});

 </script>
<?php include('stopka.php'); ?>
